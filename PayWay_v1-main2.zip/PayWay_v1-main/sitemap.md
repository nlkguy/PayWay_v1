# FinCoreBMS v4 Sitemap 

- employee-login :smile
- employee-dashboard
- employee-register
- employee-profile
- employee-list
- employee-update
- employee-delete
---

- customer-login
- customer-dashboard
- customer-register
- customer-profile
- customer-list
- customer-update
- customer-delete

---

- transaction-create
- transaction-list

---

- loan-request
- loan-update
- loan-list
- loan-details

---

- account-create
- account-update
- account-delete
- account-deposit
- account-withdraw
- account-statement
- account-list

---

- misc-contact-us
- misc-about-us
- misc-privacy-policy
- misc-security-policy