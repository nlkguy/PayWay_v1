package com.fincore.controller;

import com.fincore.dao.TransactionDAO;
import com.fincore.model.Transaction;
import java.io.IOException;
import java.math.BigDecimal;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
@WebServlet("/ViewTransaction")
public class ViewTransactionServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String idStr = request.getParameter("id");
        
        if (idStr != null) {
            long txId = Long.parseLong(idStr);
            TransactionDAO dao = new TransactionDAO();
            Transaction txn = dao.getTransactionById(txId);
            
            if (txn != null) {
                request.setAttribute("txn", txn);
                request.getRequestDispatcher("transaction_detail.jsp").forward(request, response);
                return;
            }
        }
        // If ID is missing or not found
        //response.sendRedirect("transaction.jsp?error=notfound");
    }
}