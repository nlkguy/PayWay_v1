package com.fincore.controller;

import com.fincore.dao.TransactionDAO;
import com.fincore.model.Transaction;
import java.io.IOException;
import java.math.BigDecimal;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.util.*;

@WebServlet("/ListTransactions")
public class ListTransactionsServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        TransactionDAO dao = new TransactionDAO();
        List<Transaction> list = dao.getAllTransactions();
        request.setAttribute("txList", list);
        request.getRequestDispatcher("transaction_list.jsp").forward(request, response);
    }
}