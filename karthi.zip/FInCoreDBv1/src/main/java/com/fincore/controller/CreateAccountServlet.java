package com.fincore.controller;

import com.fincore.dao.AccountDAO;
import com.fincore.model.Account;
import java.io.IOException;
import java.math.BigDecimal;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.util.*;


@WebServlet("/CreateAccountServlet")
public class CreateAccountServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            // Retrieve parameters from form
            long cstNo = Long.parseLong(request.getParameter("customerId"));
            String type = request.getParameter("accountType");
            String ifsc = request.getParameter("ifscCode");
            java.math.BigDecimal bal = new java.math.BigDecimal(request.getParameter("balance"));

            // Create Model object
            Account acc = new Account();
            acc.setAccCstNo(cstNo);
            acc.setAccType(type);
            acc.setIfscCode(ifsc);
            acc.setAccBal(bal);

            // Save to DB via DAO
            AccountDAO dao = new AccountDAO();
            boolean isSaved = dao.insertAccount(acc);

            if(isSaved) {
                // Redirect with success flag and the Customer ID to show in modal
                response.sendRedirect("account_create.jsp?success=true&cId=" + cstNo);
            } else {
                response.getWriter().println("Error: Could not save account. Check if Customer ID exists.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("create-account.jsp?error=invalid_data");
        }
    }
}