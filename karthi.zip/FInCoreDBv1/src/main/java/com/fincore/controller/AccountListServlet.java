package com.fincore.controller;

import com.fincore.dao.AccountDAO;
import com.fincore.model.Account;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.util.*;

@WebServlet("/AccountListServlet")
public class AccountListServlet extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        AccountDAO dao = new AccountDAO();
        List<Account> accounts = dao.getAllAccounts();
        
        // Pass the list to the JSP
        request.setAttribute("accountList", accounts);
        request.getRequestDispatcher("account_list.jsp").forward(request, response);
    }
}