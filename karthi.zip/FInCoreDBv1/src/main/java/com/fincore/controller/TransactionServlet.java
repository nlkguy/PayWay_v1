package com.fincore.controller;

import com.fincore.dao.TransactionDAO;
import com.fincore.model.Transaction;
import java.io.IOException;
import java.math.BigDecimal;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/TransactionServlet")
public class TransactionServlet extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    // 1. Get parameters from JSP (Must match the 'name' attribute in HTML)
    long senderAcc = Long.parseLong(request.getParameter("senderAcc"));
    long receiverAcc = Long.parseLong(request.getParameter("receiverAcc"));
    String type = request.getParameter("txType");
    String mode = request.getParameter("txMode");
    double amount = Double.parseDouble(request.getParameter("txAmt"));
    String description = request.getParameter("txDescr");

    // 2. Call the DAO to save to Derby
    TransactionDAO dao = new TransactionDAO();
    boolean success = dao.saveTransaction(senderAcc, receiverAcc, type, mode, amount, description);

    // 3. Send feedback back to the JSP
    if (success) {
        request.setAttribute("status", "success");
    } else {
        request.setAttribute("status", "error");
    }
    request.getRequestDispatcher("transaction_processing.jsp").forward(request, response);
}
	
}

	