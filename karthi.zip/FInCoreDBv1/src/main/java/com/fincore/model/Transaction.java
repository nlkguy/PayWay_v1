package com.fincore.model;

import java.sql.Timestamp;
import java.math.BigDecimal;

public class Transaction {
    private long txId;
    private Timestamp txTime;
    private long senderAccNo;
    private long receiverAccNo;
    private String txType;
    private String txMode;
    private BigDecimal txAmt;
    private String txDescr;

    // Default Constructor
    public Transaction() {}

    // Getters and Setters
    public long getTxId() { return txId; }
    public void setTxId(long txId) { this.txId = txId; }

    public long getSenderAccNo() { return senderAccNo; }
    public void setSenderAccNo(long senderAccNo) { this.senderAccNo = senderAccNo; }

    public long getReceiverAccNo() { return receiverAccNo; }
    public void setReceiverAccNo(long receiverAccNo) { this.receiverAccNo = receiverAccNo; }

    public String getTxType() { return txType; }
    public void setTxType(String txType) { this.txType = txType; }

    public String getTxMode() { return txMode; }
    public void setTxMode(String txMode) { this.txMode = txMode; }

    public BigDecimal getTxAmt() { return txAmt; }
    public void setTxAmt(BigDecimal txAmt) { this.txAmt = txAmt; }

    public String getTxDescr() { return txDescr; }
    public void setTxDescr(String txDescr) { this.txDescr = txDescr; }
    
    public Timestamp getTimestamp() { return txTime; }
    public void setTimestamp(Timestamp txTime) { this.txTime = txTime; }
}