package com.fincore.model;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;

public class Account {
    private long accNo;
    private long accCstNo; // Matching ACC_CST_NO
    private Date accOpenDate;
    private String accType;
    private String ifscCode;
    private String accStatus;
    private BigDecimal accBal;
    private Timestamp lastAccess;

    // Getters and Setters
    public long getAccNo() { return accNo; }
    public void setAccNo(long accNo) { this.accNo = accNo; }

    public long getAccCstNo() { return accCstNo; }
    public void setAccCstNo(long accCstNo) { this.accCstNo = accCstNo; }

    public Date getAccOpenDate() { return accOpenDate; }
    public void setAccOpenDate(Date accOpenDate) { this.accOpenDate = accOpenDate; }

    public String getAccType() { return accType; }
    public void setAccType(String accType) { this.accType = accType; }

    public String getIfscCode() { return ifscCode; }
    public void setIfscCode(String ifscCode) { this.ifscCode = ifscCode; }

    public String getAccStatus() { return accStatus; }
    public void setAccStatus(String accStatus) { this.accStatus = accStatus; }

    public BigDecimal getAccBal() { return accBal; }
    public void setAccBal(BigDecimal accBal) { this.accBal = accBal; }

    public Timestamp getLastAccess() { return lastAccess; }
    public void setLastAccess(Timestamp lastAccess) { this.lastAccess = lastAccess; }
}