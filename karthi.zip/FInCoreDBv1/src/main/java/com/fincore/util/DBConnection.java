package com.fincore.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    // Derby URL - change 'fincoreDB' to your preferred database name
    private static final String URL = "jdbc:derby:C:/derby/FinCoreDBv2"; 
    private static final String DRIVER = "org.apache.derby.jdbc.EmbeddedDriver";

    public static Connection getConnection() throws SQLException {
        try {
            Class.forName(DRIVER);
            return DriverManager.getConnection(URL);
        } catch (ClassNotFoundException e) {
            throw new SQLException("Derby JDBC Driver not found!", e);
        }
    }
}