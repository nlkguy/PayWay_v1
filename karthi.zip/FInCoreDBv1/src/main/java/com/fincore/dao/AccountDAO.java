package com.fincore.dao;

import com.fincore.model.Account;
import com.fincore.util.DBConnection;
import java.sql.*;
import java.util.*;
public class AccountDAO{
	
public boolean insertAccount(Account acc) {
    // We let Derby handle ACC_NO, ACC_OPEN_DATE, and ACC_STATUS (default ACTIVE)
    String sql = "INSERT INTO ACCOUNT (ACC_CST_NO, ACC_TYPE, IFSC_CODE, ACC_BAL) VALUES (?, ?, ?, ?)";
    try (Connection conn = DBConnection.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {
        
        ps.setLong(1, acc.getAccCstNo());
        ps.setString(2, acc.getAccType());
        ps.setString(3, acc.getIfscCode());
        ps.setBigDecimal(4, acc.getAccBal());
        
        return ps.executeUpdate() > 0;
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}
public List<Account> getAllAccounts() {
    List<Account> list = new ArrayList<>();
    // Joining with CUSTOMER table to get the name for the UI
    String sql = "SELECT * FROM ACCOUNT ORDER BY ACC_NO DESC";
    
    try (Connection conn = DBConnection.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {
        
        while (rs.next()) {
            Account a = new Account();
            a.setAccNo(rs.getLong("ACC_NO"));
            a.setAccCstNo(rs.getLong("ACC_CST_NO"));
            a.setAccType(rs.getString("ACC_TYPE"));
            a.setAccBal(rs.getBigDecimal("ACC_BAL"));
            a.setAccStatus(rs.getString("ACC_STATUS"));
            a.setAccOpenDate(rs.getDate("ACC_OPEN_DATE"));
            a.setIfscCode(rs.getString("IFSC_CODE"));
            
            
        }
    } catch (SQLException e) { e.printStackTrace(); }
    return list;
}
}