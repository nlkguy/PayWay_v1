package com.fincore.dao;

import com.fincore.model.Transaction;
import com.fincore.util.DBConnection;
import java.sql.*;
import java.util.*;

public class TransactionDAO {
	public boolean saveTransaction(long sender, long receiver, String type, String mode, double amount, String descr) {
	    boolean rowInserted = false;
	    // TX_ID is GENERATED and TX_TIME is CURRENT_TIMESTAMP, so we don't insert them manually
	    String sql = "INSERT INTO TXN (SENDER_ACC_NO, RECEIVER_ACC_NO, TX_TYPE, TX_MODE, TX_AMT, TX_DESCR) VALUES (?, ?, ?, ?, ?, ?)";
	    
	    try (Connection conn = DBConnection.getConnection();
	         PreparedStatement pstmt = conn.prepareStatement(sql)) {
	        
	        pstmt.setLong(1, sender);
	        pstmt.setLong(2, receiver);
	        pstmt.setString(3, type);
	        pstmt.setString(4, mode);
	        pstmt.setDouble(5, amount);
	        pstmt.setString(6, descr);
	        
	        rowInserted = pstmt.executeUpdate() > 0;
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return rowInserted;
	}
	
	public Transaction getTransactionById(long txId) {
	    Transaction txn = null;
	    String sql = "SELECT * FROM TXN WHERE TX_ID = ?";
	    
	    try (Connection conn = DBConnection.getConnection();
	         PreparedStatement pstmt = conn.prepareStatement(sql)) {
	        
	        pstmt.setLong(1, txId);
	        ResultSet rs = pstmt.executeQuery();
	        
	        if (rs.next()) {
	            txn = new Transaction();
	            txn.setTxId(rs.getLong("TX_ID"));
	            txn.setTimestamp(rs.getTimestamp("TX_TIME"));
	            txn.setSenderAccNo(rs.getLong("SENDER_ACC_NO"));
	            txn.setReceiverAccNo(rs.getLong("RECEIVER_ACC_NO"));
	            txn.setTxType(rs.getString("TX_TYPE"));
	            txn.setTxMode(rs.getString("TX_MODE"));
	            txn.setTxAmt(rs.getBigDecimal("TX_AMT"));
	            txn.setTxDescr(rs.getString("TX_DESCR"));
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return txn;
	}
	public List<Transaction> getAllTransactions() {
	    List<Transaction> list = new ArrayList<>();
	    String sql = "SELECT * FROM TXN ORDER BY TX_TIME DESC";
	    try (Connection conn = DBConnection.getConnection();
	         PreparedStatement pstmt = conn.prepareStatement(sql)) {
	        ResultSet rs = pstmt.executeQuery();
	        while (rs.next()) {
	            Transaction t = new Transaction();
	            t.setTxId(rs.getLong("TX_ID"));
	            t.setSenderAccNo(rs.getLong("SENDER_ACC_NO"));
	            t.setReceiverAccNo(rs.getLong("RECEIVER_ACC_NO"));
	            t.setTxAmt(rs.getBigDecimal("TX_AMT"));
	            t.setTxType(rs.getString("TX_TYPE"));
	            t.setTxMode(rs.getString("TX_MODE"));
	            t.setTimestamp(rs.getTimestamp("TX_TIME"));
	            list.add(t);
	        }
	    } catch (Exception e) { e.printStackTrace(); }
	    return list;
	}
}